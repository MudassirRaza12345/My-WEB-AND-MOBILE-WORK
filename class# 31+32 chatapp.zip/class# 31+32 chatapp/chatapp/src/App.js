import React from 'react';
import './App.css';
import Home from './containers/Home'

class App extends React.Component{
  render() {
    return (
      <div>
        <Home />
      </div>
    )
  }

}

export default App;


// Now we Going to Connect Facebook through Firebase in our project  