import  firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/database';
var firebaseConfig = {
    apiKey: "AIzaSyCYYgVzgfdPK1ViAN5kgtAsakvj2oX89bg",
    authDomain: "chatapp-in-react.firebaseapp.com",
    projectId: "chatapp-in-react",
    storageBucket: "chatapp-in-react.appspot.com",
    messagingSenderId: "792537716461",
    appId: "1:792537716461:web:20e98a81d3790fcc999ee4",
    measurementId: "G-CRD09DKRKE"
  };
//   Initialize Firebase
 
//   firebase.analytics();

var Firebase=firebase.initializeApp(firebaseConfig)
export default Firebase;
